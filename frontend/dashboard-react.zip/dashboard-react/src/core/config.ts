// // src/core/config.ts
// export const AppConfig = {
// //   apiBaseUrl: import.meta.env.VITE_API_BASE_URL as string,
//     apiBaseUrl: import.meta.env.VITE_API_BASE_URL as string,
//     tilesUrl: import.meta.env.VITE_TILES_URL as string,
// };

// if (!AppConfig.apiBaseUrl) {
//   // opcional: avisa en consola para no perder tiempo
//   // eslint-disable-next-line no-console
//   console.warn("[Config] Falta VITE_API_BASE_URL en tu .env");
// }
